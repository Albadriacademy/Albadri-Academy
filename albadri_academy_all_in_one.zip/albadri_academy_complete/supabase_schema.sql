-- أكاديمية البدري: مخطط قاعدة بيانات تأسيسي لـ Supabase
-- نفّذ هذا الملف كاملاً من SQL Editor في مشروع Supabase جديد.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create table if not exists public.courses (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 description text default '',
 level text default 'مبتدئ',
 published boolean not null default false,
 created_by uuid references public.profiles(id),
 created_at timestamptz not null default now()
);
create table if not exists public.lessons (
 id uuid primary key default gen_random_uuid(),
 course_id uuid not null references public.courses(id) on delete cascade,
 title text not null,
 content text default '',
 sort_order integer not null default 0,
 created_at timestamptz not null default now()
);
create table if not exists public.lesson_progress (
 user_id uuid not null references public.profiles(id) on delete cascade,
 lesson_id uuid not null references public.lessons(id) on delete cascade,
 completed boolean not null default false,
 completed_at timestamptz,
 primary key(user_id,lesson_id)
);

create table if not exists public.accounts (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 code text not null,
 name text not null,
 account_type text not null check (account_type in ('asset','liability','equity','revenue','expense')),
 normal_balance text not null check (normal_balance in ('debit','credit')),
 parent_id uuid references public.accounts(id),
 is_system boolean not null default false,
 created_at timestamptz not null default now(),
 unique(user_id,code)
);
create table if not exists public.journal_entries (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 entry_date date not null,
 reference text,
 memo text not null,
 total_debit numeric(18,2) not null default 0,
 total_credit numeric(18,2) not null default 0,
 status text not null default 'posted' check(status in ('draft','posted')),
 created_at timestamptz not null default now(),
 check(total_debit >= 0 and total_credit >= 0)
);
create table if not exists public.journal_lines (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 entry_id uuid not null references public.journal_entries(id) on delete cascade,
 account_id uuid not null references public.accounts(id),
 debit numeric(18,2) not null default 0,
 credit numeric(18,2) not null default 0,
 check(debit >= 0 and credit >= 0),
 check(not (debit > 0 and credit > 0)),
 check(debit > 0 or credit > 0)
);

-- حماية البيانات: كل مستخدم يرى بياناته فقط، والدورات المنشورة متاحة للمسجلين.
alter table public.profiles enable row level security;
alter table public.courses enable row level security;
alter table public.lessons enable row level security;
alter table public.lesson_progress enable row level security;
alter table public.accounts enable row level security;
alter table public.journal_entries enable row level security;
alter table public.journal_lines enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin') $$;

drop policy if exists "profile read self" on public.profiles;
create policy "profile read self" on public.profiles for select to authenticated using(id=auth.uid() or public.is_admin());
drop policy if exists "profile update self" on public.profiles;
create policy "profile update self" on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid() and role='student');

drop policy if exists "published courses read" on public.courses;
create policy "published courses read" on public.courses for select to authenticated using(published=true or public.is_admin());
drop policy if exists "admin manage courses" on public.courses;
create policy "admin manage courses" on public.courses for all to authenticated using(public.is_admin()) with check(public.is_admin());

drop policy if exists "lessons read" on public.lessons;
create policy "lessons read" on public.lessons for select to authenticated using(exists(select 1 from public.courses c where c.id=course_id and (c.published=true or public.is_admin())));
drop policy if exists "admin manage lessons" on public.lessons;
create policy "admin manage lessons" on public.lessons for all to authenticated using(public.is_admin()) with check(public.is_admin());

drop policy if exists "progress own" on public.lesson_progress;
create policy "progress own" on public.lesson_progress for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());

drop policy if exists "accounts own" on public.accounts;
create policy "accounts own" on public.accounts for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
drop policy if exists "entries own" on public.journal_entries;
create policy "entries own" on public.journal_entries for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
drop policy if exists "lines own" on public.journal_lines;
create policy "lines own" on public.journal_lines for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());

-- إنشاء شجرة حسابات افتراضية لكل مستخدم جديد.
create or replace function public.seed_default_accounts()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
 insert into public.accounts(user_id,code,name,account_type,normal_balance,is_system) values
 (new.id,'1000','الأصول','asset','debit',true),
 (new.id,'1100','النقدية بالصندوق','asset','debit',true),
 (new.id,'1200','البنك','asset','debit',true),
 (new.id,'1300','العملاء','asset','debit',true),
 (new.id,'1500','الأصول الثابتة','asset','debit',true),
 (new.id,'2000','الالتزامات','liability','credit',true),
 (new.id,'2100','الموردون','liability','credit',true),
 (new.id,'3000','حقوق الملكية','equity','credit',true),
 (new.id,'3100','رأس المال','equity','credit',true),
 (new.id,'4000','الإيرادات','revenue','credit',true),
 (new.id,'4100','إيرادات المبيعات','revenue','credit',true),
 (new.id,'5000','المصروفات','expense','debit',true),
 (new.id,'5100','مصروف الرواتب','expense','debit',true),
 (new.id,'5200','مصروف الإيجار','expense','debit',true);
 return new;
end;
$$;
drop trigger if exists seed_accounts_after_profile on public.profiles;
create trigger seed_accounts_after_profile after insert on public.profiles
for each row execute procedure public.seed_default_accounts();

-- ترقية أول حساب إلى مدير: استبدل البريد ثم نفّذ السطر بعد التسجيل.
-- update public.profiles set role='admin' where id=(select id from auth.users where email='YOUR_EMAIL@example.com');
